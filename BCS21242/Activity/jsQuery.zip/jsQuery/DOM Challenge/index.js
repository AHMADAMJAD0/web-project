const para = jQuery("#btn").css({"color":"red","width":"202px","background-color":"lightblue"});

const check = $("li").hasClass("list");
console.log(check)

$("ul").addClass("another");

// Get the text content of the first <p> element
var textContent = $("p").text();
console.log(textContent);
// Set the text content of all <p> elements
// $(" p").text("This is new text.");
$("body > p").text("This is new text.");


// Get the HTML content of the first <div> element
var htmlContent = $("div").html();
console.log(htmlContent);
// Set the HTML content of all <div> elements
$("div").html("<strong>This is bold text.</strong>");

// Get the 'href' attribute value of the first <a> element
var hrefValue = $("a").attr("href");
console.log(hrefValue);

// $("#btn").on('click',()=>alert("button clicked!"));

$("#btn").click(function(){
    $(this).css("background-color",'lime')
});

$("div").hover(function(){
    $(this).text('hover')
    $(this).css("color","blue")
})

$('#btn').off('click').animate({opacity: 0.5},5000)

$("#para").on("click",".child",function(){
    alert('child element clicked.');
});
