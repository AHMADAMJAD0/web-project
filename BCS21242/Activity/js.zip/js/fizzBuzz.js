let numbers = [];
let count =1;

function fizzBuzz(){
    if(count%3==0&&count%5==0){
        numbers.push("FizzBuzz");
    }
    else if(count%3==0){
        numbers.push("Fizz");
    }
    else if(count%5==0){
        numbers.push("Buzz");
    }
    else{
        numbers.push(count);
    }
}
while(count<=100){
    fizzBuzz();
    count++;
}
console.log(numbers);