const readline = require('readline');

// Create an interface to read from the standard input (stdin) and write to the standard output (stdout)
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Function to prompt the user for input
function askQuestion(query) {
    return new Promise((resolve) => rl.question(query, resolve));
}

// Main function to handle the input process
async function main() {
    try {
        // Prompt for the first input
        let input1 = await askQuestion('Enter height(in cm): ');

        // Prompt for the second input
        let weight = await askQuestion('Enter weight(in kg): ');

        let height=input1/100;
        height=height*height;

        let bmi=weight/height;
        // Display the inputs
        console.log(`BMI ${bmi.toFixed(2)}`);
    } finally {
        // Close the readline interface
        rl.close();
    }
}

// Run the main function
main();
