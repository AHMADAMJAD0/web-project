let  userString = prompt('enter string ');       // here prompt () will not work bcz it's used in web page so we can use readline module for the input
let userStringLength = userString.length;
let remainingCharacters = 240-userStringLength;
console.log('You have entered '+userStringLength + ' characters and you have '+ remainingCharacters +' remaining characters.')

// ------String.slice() 
// let  userString = prompt('enter string ');
// let userStringLength = userString.length;
// let remainingCharacters = 240-userStringLength;
// let newString = userString.slice(0,100);
// alert('First 100 characters of Your entered string are: '+''+ newString)


// -----String.slice()  String.toUpperCase
// let userName=prompt("enter name");
// let capitalName=userName.slice(0,1).toUpperCase();
// capitalName += userName.slice(1);
// alert('Hello, '+ '' + capitalName)