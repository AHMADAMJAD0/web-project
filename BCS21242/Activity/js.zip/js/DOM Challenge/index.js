// document.query

document.querySelector('ul').lastElementChild.innerText = 'Changed'

const element = document.querySelectorAll('li');
element[1].classList.remove('list')
element[1].classList.add('another')