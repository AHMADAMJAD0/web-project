prompt("Enter your name: ");
prompt("Enter your's friend name: ")
let randpercentage = Math.floor(Math.random()*100)+1;
//  if we want to include 0 then Math.floor(Math.random()*101);
alert(`Your friendship score is ${randpercentage} %.`)


// prompt("Enter your name: ");
// prompt("Enter your's friend name: ")
// let fsScore = Math.floor(Math.random()*100)+1;
// if(fsScore>=80 && fsScore<=100){
//     alert("Marvelous.")
// }
// else if(fsScore>=60 && fsScore<=79){
//     alert("Very Good.")
// }
// else if(fsScore>=40 && fsScore<=59){
//     alert("Not Bad.")
// }
// else{
//     alert('Too Bad!')
// }

// Leap year code
let year=parseInt(prompt("Enter year: "));
if(year%4==0){
    if(year%100==0){
        if(year%400==0){
            alert('Leap year.'); 
        }
        else{
            alert('Not a leap year.');  
        }
    }
    else{
      alert('Leap year.') ; 
    }
}
else{
    alert('Not a leap year.');  
}
// let year=parseInt(prompt("Enter year: "));
// if((year%4==0 && year%100!=0) || year%400==0){
//     alert('Leap year.');    
// }
// else{
//     alert('Not a leap year.');  
// }

