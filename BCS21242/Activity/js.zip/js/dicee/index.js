function randNum(){
    var randNum1 = (Math.floor(Math.random()*6))+1;
    return randNum1
}
 
function imgChange(){
    const img = document.querySelector('.img1')
    var num1= randNum();
    img.setAttribute('src',`./images/dice${num1}.png`)
    const element = document.querySelector('.img2')
    var num2 = randNum();
    element.setAttribute('src', `./images/dice${num2}.png`)

    if(num1>num2){
        const heading = document.getElementsByTagName('h1');
        heading[0].innerHTML = 'Player 1 won'
    }
    if(num1<num2){
        const heading = document.getElementsByTagName('h1')
        heading[0].innerHTML = 'Player 2 won'
    }
    if(num1==num2){
        const heading = document.getElementsByTagName('h1')
        heading[0].innerHTML =  'Draw!'
    }
}

imgChange()