const readline = require('readline');

// Create an interface to read from the standard input (stdin) and write to the standard output (stdout)
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Prompt the user for input
rl.question('Enter your current age year: ', (answer) => {

    let remainingYears=90-answer;
    let remainingMonths=remainingYears*12;
    let remainingWeeks=remainingYears*52;
    let remainingDays=remainingYears*365;
    // Display the user's input
    console.log(`You have ${remainingDays} days, ${remainingWeeks} weeks, and ${remainingMonths} months left.`);
    
    // Close the readline interface
    rl.close();
});
