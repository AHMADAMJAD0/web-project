let guest = ['Ali','Talha','Hammad','Zubair','Umair','Hashir','Naseer','Imran','Rashid'];
let userName = prompt("Enter your name: ");
let check = guest.includes(userName);
if(check==true){
    alert("Welcome")
}
else{
    alert("Sorry!!!")
}
